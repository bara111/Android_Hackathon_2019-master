package com.lawerance.hack;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Images_activity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private Myadapter mAdapter;
    private TextView task2;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<galley> mImageList;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_images_activity);
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        mRecyclerView = findViewById(R.id.my_recycler_view);
        mImageList = new ArrayList<>();
        task2 = findViewById(R.id.task);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mRecyclerView.setHasFixedSize(true);
        Log.v("bara_","debug");

        mDatabaseReference.child("users/" + "wxc0sL8JdxVWPWhFCN7fL3guEAV2").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    for (DataSnapshot postSnapShot : dataSnapshot.getChildren()) {
                        Log.v("bara_","bara_");
                        galley post = postSnapShot.getValue(galley.class);
                        mImageList.add(post);


                    }
                    mAdapter = new Myadapter(Images_activity.this,mImageList);
                    mRecyclerView.setAdapter(mAdapter);

                }




            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
